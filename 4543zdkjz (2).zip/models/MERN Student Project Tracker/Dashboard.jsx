import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import API from "../services/api";

function Dashboard() {
  const [projects, setProjects] = useState([]);

  useEffect(() => {
    loadProjects();
  }, []);

  const loadProjects = async () => {
    const response = await API.get("/projects");
    setProjects(response.data);
  };

  return (
    <div>
      <h1>Student Project Tracker</h1>

      <h2>Projects</h2>

      {projects.map((project) => (
        <div key={project._id}>
          <h3>{project.title}</h3>

          <p>{project.description}</p>

          <p>
            Deadline:{" "}
            {project.deadline
              ? new Date(project.deadline).toLocaleDateString()
              : "Not set"}
          </p>

          <Link to={`/project/${project._id}`}>
            View Project
          </Link>
        </div>
      ))}
    </div>
  );
}

export default Dashboard;