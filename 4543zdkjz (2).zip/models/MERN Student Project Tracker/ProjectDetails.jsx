import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import API from "../services/api";

function ProjectDetails() {
  const { id } = useParams();

  const [project, setProject] = useState(null);
  const [tasks, setTasks] = useState([]);

  useEffect(() => {
    loadProject();
    loadTasks();
  }, []);

  const loadProject = async () => {
    const response = await API.get(`/projects/${id}`);
    setProject(response.data);
  };

  const loadTasks = async () => {
    const response = await API.get(`/tasks/project/${id}`);
    setTasks(response.data);
  };

  if (!project) {
    return <h2>Loading...</h2>;
  }

  const completed = tasks.filter(
    (task) => task.status === "Completed"
  ).length;

  const progress =
    tasks.length === 0
      ? 0
      : Math.round((completed / tasks.length) * 100);

  return (
    <div>
      <h1>{project.title}</h1>

      <p>{project.description}</p>

      <h3>Team Members</h3>

      {project.teamMembers.map((member) => (
        <p key={member._id}>
          {member.name}
        </p>
      ))}

      <h3>Progress: {progress}%</h3>

      <progress value={progress} max="100"></progress>

      <h3>Tasks</h3>

      {tasks.map((task) => (
        <div key={task._id}>
          <h4>{task.title}</h4>
          <p>Status: {task.status}</p>
          <p>Comment: {task.comments}</p>
        </div>
      ))}
    </div>
  );
}

export default ProjectDetails;